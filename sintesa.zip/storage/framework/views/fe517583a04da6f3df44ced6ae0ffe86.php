<?php $__env->startSection('title', 'Kartu Pelajar'); ?>
<?php $__env->startSection('page_title', isset($siswas) ? 'Preview Kartu Pelajar Massal' : 'Preview Kartu Pelajar'); ?>

<?php $__env->startSection('content'); ?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap');

/* ====== PREVIEW CONTAINER ====== */
.preview-container {
    font-family: 'Poppins', sans-serif !important;
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
    gap: 1rem;
    padding: 10px;
    width: 100%;
}

.preview-container *:not(i) { 
    font-family: 'Poppins', sans-serif !important;
}

/* IFRAME PREVIEW LAYAR MONETOR */
iframe.preview-frame {
    width: 100%;
    max-width: 450px;
    height: 290px;
    border: none;
    background: transparent;
    margin-bottom: 10px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.15); 
    border-radius: 8px;
    overflow: hidden;
}

/* ====== TOMBOL AKSI ====== */
.action-buttons {
    display: flex; 
    justify-content: center; 
    flex-wrap: wrap; 
    gap: 10px;
    margin-top: 10px; 
    width: 100%; 
    max-width: 750px;
}

.btn-custom {
    padding: 10px 22px;
    border: none;
    border-radius: 8px;
    color: white;
    font-weight: 600;
    font-size: 15px;
    cursor: pointer;
    transition: 0.2s ease;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    font-family: 'Poppins', sans-serif;
}

.btn-custom i {
    font-family: "Font Awesome 6 Free" !important;
    font-weight: 900;
    font-style: normal;
    font-size: 1.1rem;
}

.btn-custom:hover { opacity: 0.9; color: white; }
.btn-cetak { background-color: #28a745; }
.btn-edit { background-color: #007bff; }
.btn-batal { background-color: #6c757d; }
.btn-orange { background-color: #f39c12; }

/* ====== FORM EDIT ATRIBUT ====== */
#footerFormContainer { width: 100%; display: flex; justify-content: center; }
#footerForm {
    display: inline-block; background: #f0f4ff; padding: 20px;
    border-radius: 8px; text-align: left; width: 100%; max-width: 750px;
    box-sizing: border-box; border: 1px solid #dbeafe;
}

.form-grid {
    display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 15px; margin-bottom: 20px;
}
.form-group { display: flex; flex-direction: column; }
.form-group label { font-size: 0.9rem; font-weight: 600; color: #17375d; margin-bottom: 5px; }
.form-group input { padding: 8px 12px; border-radius: 6px; border: 1px solid #ccc; font-size: 0.95rem; width: 100%; box-sizing: border-box; }

/* ====== PENGATURAN CETAK BAHAN INPUT PORTRAIT (53.98mm x 85.6mm) ====== */
#printArea { display: none; }

@page {
    size: 53.98mm 85.6mm portrait; /* Bahan masuk secara Portrait */
    margin: 0;
}

@media print {
    html, body {
        width: 53.98mm;
        height: 85.6mm;
        margin: 0 !important;
        padding: 0 !important;
        background: none !important;
        overflow: hidden;
    }

    body * { visibility: hidden !important; }

    #printArea, #printArea * { 
        visibility: visible !important; 
    }

    #printArea {
        display: block !important;
        position: absolute;
        left: 0;
        top: 0;
        width: 53.98mm;
        height: 85.6mm;
        margin: 0;
        padding: 0;
    }

    .print-sheet {
        width: 53.98mm;
        height: 85.6mm;
        margin: 0;
        padding: 0;
    }

    .print-card {
        width: 53.98mm;
        height: 85.6mm;
        page-break-after: always;
        page-break-inside: avoid;
        margin: 0;
        padding: 0;
        border: none !important;
        position: relative;
    }

    /* Merotasi Iframe agar hasil cetakLandscape pas pada media Portrait */
    .print-card iframe {
        width: 85.6mm !important;
        height: 53.98mm !important;
        border: none !important;
        overflow: hidden !important;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%) rotate(-90deg);
        transform-origin: center center;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
    }

    .noprint { display: none !important; }
}
</style>

<div class="container py-3">

    <div class="noprint text-center mb-3">
        <p class="text-muted" style="font-size: 0.95rem;">
            <?php echo e(isset($siswas) ? 'Preview kartu pelajar sebelum cetak massal' : 'Preview Kartu Pelajar (Depan)'); ?>

        </p>
    </div>

    <div class="preview-container noprint">
    
    <?php if(isset($siswas)): ?>
        
        <?php $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <iframe class="preview-frame" src="<?php echo e(route('admin.kartupelajar.frame', $siswa->nis)); ?>"></iframe>
            <hr style="width:100%; max-width:450px; border:1px dashed #ccc; margin: 15px 0;">
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="action-buttons">
            <button onclick="window.print()" class="btn-custom btn-cetak">
                <i class="fa-solid fa-print"></i> Cetak Semua Kartu
            </button>

            <?php if (! (auth('guru')->user()->role === 'kesiswaan')): ?>
                <button type="button" class="btn-custom btn-edit" onclick="toggleFooterForm()">
                    <i class="fa-solid fa-cog"></i> Edit Data Kartu
                </button>
            <?php endif; ?>

            <a href="<?php echo e(route('admin.kartupelajar.index')); ?>" class="btn-custom btn-batal">
                <i class="fa-solid fa-times"></i> Kembali
            </a>
        </div>

    <?php else: ?>
        
        <iframe class="preview-frame" id="kartuFrame" src="<?php echo e(route('admin.kartupelajar.frame', $siswa->nis)); ?>"></iframe>

        <div class="action-buttons">
            <button onclick="window.print()" class="btn-custom btn-cetak">
                <i class="fa-solid fa-print"></i> Cetak Kartu
            </button>

            <?php if (! (auth('guru')->user()->role === 'kesiswaan')): ?>
                <a href="<?php echo e(route('admin.datasiswa.edit', $siswa->nis)); ?>" class="btn-custom btn-orange">
                    <i class="fa-solid fa-user-pen"></i> Edit Siswa
                </a>

                <button type="button" class="btn-custom btn-edit" onclick="toggleFooterForm()">
                    <i class="fa-solid fa-cog"></i> Edit Data Kartu
                </button>
            <?php endif; ?>

            <a href="<?php echo e(route('admin.kartupelajar.index')); ?>" class="btn-custom btn-batal">
                <i class="fa-solid fa-arrow-left"></i> Kembali
            </a>
        </div>
    <?php endif; ?>

    
    <?php if (! (auth('guru')->user()->role === 'kesiswaan')): ?>
    <div id="footerFormContainer" style="display:none; margin-top:20px;">
        <form id="footerForm" onsubmit="return updateFrameFooter();">
            <h4 style="color:#17375d; margin-bottom:15px; border-bottom: 1px solid #ccc; padding-bottom: 10px;">
                <i class="fa-solid fa-pen-to-square"></i> Edit Atribut Kartu
            </h4>
            <div class="form-grid">
                <div class="form-group">
                    <label>Bulan:</label>
                    <input type="text" name="bulan" id="bulan" value="<?php echo e(date('F')); ?>" required>
                </div>
                <div class="form-group">
                    <label>Tahun:</label>
                    <input type="number" name="tahun" id="tahun" value="<?php echo e(date('Y')); ?>" required>
                </div>
                <div class="form-group">
                    <label>Nama Kepala Sekolah:</label>
                    <input type="text" name="nama_kepsek" id="nama_kepsek" placeholder="Nama Kepsek" required>
                </div>
                <div class="form-group">
                    <label>NIP:</label>
                    <input type="text" name="nip" id="nip" placeholder="NIP" required>
                </div>
                <div class="form-group" style="grid-column: 1 / -1;">
                    <label>Gambar Cap & TTD:</label>
                    <input type="file" id="cap_kepsek" accept="image/*" style="background: #fff;">
                    <small class="text-muted">Biarkan kosong jika tidak ingin mengubah.</small>
                </div>
            </div>
            <div style="margin-top: 15px; text-align:center; display: flex; gap: 10px; justify-content: center;">
                <button type="submit" class="btn-custom btn-cetak" style="flex:1;">
                    <i class="fa-solid fa-save"></i> Simpan
                </button>
                <button type="button" class="btn-custom btn-batal" onclick="toggleFooterForm()" style="flex:1;">
                    Batal
                </button>
            </div>
        </form>
    </div>
    <?php endif; ?>

    </div>

    
    <div id="printArea">
        <div class="print-sheet">
            <?php if(isset($siswas)): ?>
                <?php $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="print-card">
                    <iframe src="<?php echo e(route('admin.kartupelajar.frame', $siswa->nis)); ?>" scrolling="no"></iframe>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="print-card">
                    <iframe src="<?php echo e(route('admin.kartupelajar.frame', $siswa->nis)); ?>" scrolling="no"></iframe>
                </div>
            <?php endif; ?>
        </div>
    </div>

</div>

<script>
function toggleFooterForm() {
    const form = document.getElementById('footerFormContainer');
    form.style.display = (form.style.display === 'none' || form.style.display === '') ? 'flex' : 'none';
    if(form.style.display === 'flex') { form.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
}

function updateFrameFooter() {
    const bulan = document.getElementById('bulan').value;
    const tahun = document.getElementById('tahun').value;
    const nama_kepsek = document.getElementById('nama_kepsek').value;
    const nip = document.getElementById('nip').value;
    const fileInput = document.getElementById('cap_kepsek');
    const file = fileInput.files[0];

    if (file) {
        const reader = new FileReader();
        reader.onload = function (e) {
            const cap_kepsek = encodeURIComponent(e.target.result);
            refreshFrames(bulan, tahun, nama_kepsek, nip, cap_kepsek);
        };
        reader.readAsDataURL(file);
    } else {
        refreshFrames(bulan, tahun, nama_kepsek, nip, '');
    }
    toggleFooterForm();
    return false;
}

function refreshFrames(bulan, tahun, nama_kepsek, nip, cap_kepsek) {
    const previewFrames = document.querySelectorAll('.preview-frame');
    const printFrames = document.querySelectorAll('#printArea iframe');
    document.body.style.cursor = 'wait';
    [...previewFrames, ...printFrames].forEach(frame => {
        let src = frame.src;
        if(src.indexOf('?') !== -1) { src = src.split('?')[0]; }
        frame.src = `${src}?bulan=${encodeURIComponent(bulan)}&tahun=${encodeURIComponent(tahun)}&nama_kepsek=${encodeURIComponent(nama_kepsek)}&nip=${encodeURIComponent(nip)}&cap_kepsek=${cap_kepsek}`;
    });
    setTimeout(() => { document.body.style.cursor = 'default'; }, 500);
}
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\Downloads\sintesa-skaduta\resources\views/admin/kartupelajar/preview.blade.php ENDPATH**/ ?>