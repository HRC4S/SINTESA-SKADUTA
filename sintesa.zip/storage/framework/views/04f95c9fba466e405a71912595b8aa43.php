<?php $__env->startSection('title', 'Manajemen Role'); ?>
<?php $__env->startSection('page_title', 'Manajemen Role'); ?>

<?php $__env->startSection('content'); ?>


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap');
    * { font-family: 'Poppins', sans-serif; }

    /* ===========================
       1. FILTER TAB MENU STYLE
       =========================== */
    .tab-container {
        display: flex;
        gap: 10px;
        margin-bottom: 20px;
        overflow-x: auto; /* Scroll samping di HP */
        padding-bottom: 5px;
        -webkit-overflow-scrolling: touch;
    }

    .tab-menu {
        padding: 10px 20px;
        border-radius: 8px;
        background: #e0e7ff; /* Biru muda */
        color: #123B6B;
        font-weight: 600;
        font-size: 14px;
        text-decoration: none;
        white-space: nowrap;
        transition: 0.3s;
        border: 1px solid transparent;
    }

    .tab-menu:hover {
        background: #c7d2fe;
        color: #0a2240;
    }

    /* State Aktif (Tab yang dipilih) */
    .tab-menu.active {
        background: #123B6B; /* Biru Utama */
        color: white;
        box-shadow: 0 4px 6px rgba(18, 59, 107, 0.2);
    }

    /* ===========================
       2. CONTAINER & TOOLBAR
       =========================== */
    .table-container {
        background: #fff;
        border-radius: 12px;
        padding: 20px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.05);
    }

    .top-bar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
        gap: 15px;
        flex-wrap: wrap;
    }

    /* Search Box */
    .search-form { flex: 1; min-width: 250px; }
    .search-wrapper { position: relative; width: 100%; }
    
    .search-box {
        border: 1px solid #d1d5db;
        border-radius: 8px;
        padding: 10px 10px 10px 40px;
        width: 100%;
        font-size: 14px;
        box-sizing: border-box;
    }
    .search-wrapper i {
        position: absolute; top: 50%; left: 12px;
        transform: translateY(-50%); color: #9ca3af;
    }

    /* Tombol Tambah */
    .btn-add {
        background: #123B6B; /* Hijau */
        color: white;
        border-radius: 8px;
        font-weight: 600;
        padding: 10px 20px;
        text-decoration: none;
        font-size: 14px;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        white-space: nowrap;
        transition: 0.2s;
    }
    .btn-add:hover { background: #218838; color: white; }

    /* ===========================
       3. TABLE STYLE (ORIGINAL COLOR)
       =========================== */
    .table-responsive {
        width: 100%;
        overflow-x: auto;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        min-width: 850px; /* Lebar minimal agar rapi */
    }

    /* HEADER WARNA GELAP (ORIGINAL) */
    thead {
        background: #2c3e50; /* Warna Asli */
        color: white;
        border-bottom: 2px solid #1a252f;
    }

    th, td {
        padding: 12px 15px;
        text-align: left;
        border-bottom: 1px solid #eee;
        font-size: 14px;
        vertical-align: middle;
    }

    th { font-weight: 600; }
    
    tbody tr:hover { background-color: #f1f1f1; }

    /* Role Badge */
    .role-badge {
        border-radius: 20px;
        padding: 5px 12px;
        font-size: 12px;
        font-weight: 600;
        display: inline-block;
        min-width: 80px;
        text-align: center;
        color: white; /* Teks Putih */
    }

    /* Action Buttons */
    .btn-action {
        border: none; background: none; cursor: pointer;
        font-size: 16px; margin: 0 4px; transition: 0.2s;
    }
    .btn-edit { color: #f39c12; }
    .btn-edit:hover { opacity: 0.8; }
    .btn-delete { color: #dc3545; }
    .btn-delete:hover { opacity: 0.8; }

    /* ===========================
       MOBILE RESPONSIVE
       =========================== */
    @media (max-width: 768px) {
        .top-bar { flex-direction: column; align-items: stretch; }
        .search-form { width: 100%; }
        .btn-add { justify-content: center; }
        .tab-menu { flex: 0 0 auto; } 
    }
</style>


<div class="tab-container">
    <a href="<?php echo e(route('admin.role.index', ['role' => 'admin'])); ?>" 
       class="tab-menu <?php echo e(request('role') == 'admin' ? 'active' : ''); ?>">
       Admin
    </a>

    <a href="<?php echo e(route('admin.role.index', ['role' => 'guru_bk'])); ?>" 
       class="tab-menu <?php echo e(request('role') == 'guru_bk' ? 'active' : ''); ?>">
       Guru BK
    </a>

    <a href="<?php echo e(route('admin.role.index', ['role' => 'guru'])); ?>" 
       class="tab-menu <?php echo e(request('role') == 'guru' ? 'active' : ''); ?>">
       Guru
    </a>

    <a href="<?php echo e(route('admin.role.index', ['role' => 'kesiswaan'])); ?>" 
       class="tab-menu <?php echo e(request('role') == 'kesiswaan' ? 'active' : ''); ?>">
       Kesiswaan
    </a>

    <a href="<?php echo e(route('admin.role.index', ['role' => 'Siswa'])); ?>" 
       class="tab-menu <?php echo e(request('role') == 'Siswa' ? 'active' : ''); ?>">
       Siswa
    </a>
</div>

<div class="table-container">
    
    
    <div class="top-bar">
        
        <form method="GET" action="<?php echo e(route('admin.role.index')); ?>" class="search-form">
            
            <input type="hidden" name="role" value="<?php echo e(request('role', 'admin')); ?>">

            <div class="search-wrapper">
                <i class="fas fa-search"></i>
                <input type="text" name="search" value="<?php echo e(request('search')); ?>"
                    class="search-box" placeholder="Cari Nama, NIS, atau Email...">
            </div>
        </form>

        <a href="<?php echo e(route('admin.role.create')); ?>" class="btn-add">
            <i class="fas fa-plus"></i> Tambah User
        </a>
    </div>

    
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th style="width: 5%; text-align: center;">No</th>
                    <th>Nama Pengguna</th>
                    <th>NIS / NIP</th>
                    <th>Email</th>
                    <th style="text-align: center;">Role</th>

                    
                    <?php if(request('role') == 'guru'): ?>
                        <th>Wali Kelas</th>
                    <?php endif; ?>

                    <th style="text-align: center;">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td style="text-align: center;"><?php echo e($index + 1); ?></td>
                        
                        <td>
                            <strong><?php echo e($role->nama_lengkap ?? $role->nama ?? '-'); ?></strong>
                        </td>

                        <td><?php echo e($role->nis ?? $role->nip ?? '-'); ?></td>

                        <td><?php echo e($role->email ?? '-'); ?></td>

                        <td style="text-align: center;">
                            <?php
                                $bgColor = '#6c757d'; // Default Grey
                                if ($role->role == 'admin') $bgColor = '#0d6efd'; // Biru
                                elseif ($role->role == 'guru_bk') $bgColor = '#ffc107'; // Kuning/Gold
                                elseif ($role->role == 'kesiswaan') $bgColor = '#6610f2'; // Ungu
                                elseif ($role->role == 'guru') $bgColor = '#28a745'; // Hijau
                                elseif ($role->role == 'Siswa') $bgColor = '#17a2b8'; // Cyan
                            ?>
                            
                            <span class="role-badge" style="background-color: <?php echo e($bgColor); ?>;">
                                <?php echo e($role->role == 'guru' ? 'Guru' : ucfirst($role->role)); ?>

                            </span>
                        </td>
                        
                        <?php if(request('role') == 'guru'): ?>
                            <td><?php echo e($role->walikelas ?? '-'); ?></td>
                        <?php endif; ?>

                        <td style="text-align: center;">
                            <a href="<?php echo e(route('admin.role.edit', $role->nip ?? $role->nis)); ?>" class="btn-action btn-edit" title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>

                            <form action="<?php echo e(route('admin.role.destroy', $role->nip ?? $role->nis)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn-action btn-delete" onclick="return confirm('Yakin hapus user ini? Data tidak bisa dikembalikan.')" title="Hapus">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="<?php echo e(request('role') == 'guru' ? 7 : 6); ?>" style="text-align:center; padding: 30px; color:#777;">
                            <i class="far fa-folder-open" style="font-size: 32px; margin-bottom: 10px; display:block;"></i>
                            <br>Belum ada data user ditemukan.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\Downloads\sintesa-skaduta\resources\views/admin/role/index.blade.php ENDPATH**/ ?>