<?php $__env->startSection('title', 'Edit Role'); ?>
<?php $__env->startSection('page_title', 'Edit Role'); ?>

<?php $__env->startSection('content'); ?>


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap');
    
    /* ===========================
       BASE STYLES
       =========================== */
    * { font-family: 'Poppins', sans-serif; box-sizing: border-box; }

    .edit-container {
        display: flex;
        justify-content: center;
        padding-top: 20px;
    }

    .card-edit {
        background: #fff;
        border-radius: 12px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.08);
        width: 100%;
        max-width: 600px; /* Batas lebar di desktop */
        overflow: hidden;
    }

    /* HEADER */
    .card-header {
        background: #123B6B;
        color: white;
        padding: 20px 25px;
        border-bottom: 3px solid #0a2240;
    }
    .card-header h4 { margin: 0; font-weight: 600; font-size: 1.1rem; }

    /* BODY */
    .card-body { padding: 30px; }

    .form-group { margin-bottom: 20px; }

    label {
        font-weight: 600;
        margin-bottom: 8px;
        display: block;
        color: #333;
        font-size: 0.9rem;
    }

    /* INPUT STYLE */
    .form-control {
        width: 100%;
        padding: 12px 15px;
        border: 1px solid #d1d5db;
        border-radius: 8px;
        font-size: 14px;
        transition: 0.3s;
        background-color: #fff;
    }

    .form-control:focus {
        border-color: #123B6B;
        outline: none;
        box-shadow: 0 0 0 3px rgba(18, 59, 107, 0.1);
    }

    /* READONLY INPUT STYLE */
    .input-readonly {
        background-color: #f3f4f6;
        color: #6b7280;
        cursor: not-allowed;
        border-color: #e5e7eb;
    }

    /* BUTTONS */
    .btn-group {
        display: flex;
        justify-content: flex-end;
        gap: 15px;
        margin-top: 30px;
        padding-top: 20px;
        border-top: 1px solid #f3f4f6;
    }

    .btn {
        padding: 12px 24px;
        border-radius: 8px;
        font-weight: 600;
        font-size: 14px;
        cursor: pointer;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        transition: 0.2s;
        border: none;
    }

    .btn-primary {
        background: #123B6B;
        color: white;
    }
    .btn-primary:hover {
        background: #0f2e52;
        box-shadow: 0 4px 10px rgba(18, 59, 107, 0.2);
    }

    .btn-secondary {
        background: #e5e7eb;
        color: #374151;
    }
    .btn-secondary:hover {
        background: #d1d5db;
        color: #111;
    }

    /* ===========================
       MOBILE RESPONSIVE
       =========================== */
    @media (max-width: 768px) {
        .card-body { padding: 20px; }
        
        .btn-group {
            flex-direction: column-reverse; /* Tombol Simpan di atas */
        }
        
        .btn {
            width: 100%;
            justify-content: center;
        }
    }
</style>

<div class="edit-container">
    <div class="card-edit">
        
        
        <div class="card-header">
            <h4><i class="fas fa-user-edit"></i> Edit Role User</h4>
        </div>

        
        <div class="card-body">
            <form action="<?php echo e(route('admin.role.update', $role->nip ?? $role->nis)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                
                <div class="form-group">
                    <label>Nama Lengkap</label>
                    <input type="text" class="form-control input-readonly" 
                           value="<?php echo e($role->nama_lengkap ?? $role->nama); ?>" readonly>
                </div>

                
                <div class="form-group">
                    <label>NIP / NIS</label>
                    <input type="text" class="form-control input-readonly" 
                           value="<?php echo e($role->nip ?? $role->nis); ?>" readonly>
                </div>

                
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" class="form-control input-readonly" 
                           value="<?php echo e($role->email); ?>" readonly>
                </div>

                
                <div class="form-group">
                    <label for="role">Role Pengguna <span style="color:red">*</span></label>
                    <select name="role" id="role" class="form-control" required>
                        <?php if($role instanceof \App\Models\Siswa): ?>
                            <option value="siswa" <?php echo e(strtolower($role->role) == 'siswa' ? 'selected' : ''); ?>>Siswa</option>
                            <option value="koor_kelas" <?php echo e(strtolower($role->role) == 'koor_kelas' ? 'selected' : ''); ?>>Koor Kelas (Presensi)</option>
                        <?php else: ?>
                            <option value="admin" <?php echo e($role->role == 'admin' ? 'selected' : ''); ?>>Admin</option>
                            <option value="guru_bk" <?php echo e($role->role == 'guru_bk' ? 'selected' : ''); ?>>Guru BK</option>
                            <option value="guru" <?php echo e($role->role == 'guru' ? 'selected' : ''); ?>>Guru</option>
                            <option value="kesiswaan" <?php echo e($role->role == 'kesiswaan' ? 'selected' : ''); ?>>Kesiswaan</option>
                        <?php endif; ?>
                    </select>
                    <?php if($role instanceof \App\Models\Siswa): ?>
                        <small style="color:#666; font-size:12px; margin-top:5px; display:block;">
                            Kelas: <strong><?php echo e($role->rombel); ?></strong> — kalau dijadikan Koor Kelas, koor lama di kelas
                            yang sama otomatis diturunkan jadi siswa biasa (hanya boleh 1 koor aktif per kelas).
                        </small>
                    <?php endif; ?>
                </div>

                
                <?php if($role instanceof \App\Models\Guru): ?>
                    <div class="form-group" style="background:#f9fafb; padding:15px; border-radius:8px; border:1px dashed #ccc;">
                        <label for="walikelas" style="color:#123B6B;">
                            <i class="fas fa-chalkboard-teacher"></i> Wali Kelas (Opsional)
                        </label>
                        <select name="walikelas" id="walikelas" class="form-control">
                            <option value="">-- Tidak Menjadi Wali Kelas --</option>
                            <?php $__currentLoopData = $rombels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($r->rombel); ?>" 
                                    <?php echo e($role->walikelas == $r->rombel ? 'selected' : ''); ?>>
                                    <?php echo e($r->rombel); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <small style="color:#666; font-size:12px; margin-top:5px; display:block;">
                            Pilih kelas jika guru ini menjabat sebagai Wali Kelas.
                        </small>
                    </div>
                <?php endif; ?>

                
                <div class="btn-group">
                    <a href="<?php echo e(route('admin.role.index')); ?>" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Batal
                    </a>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Simpan Perubahan
                    </button>
                </div>

            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\Downloads\sintesa-skaduta\sintesa-skaduta\resources\views/admin/role/edit.blade.php ENDPATH**/ ?>