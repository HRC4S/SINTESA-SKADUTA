<?php $__env->startSection('title', 'Presensi Siswa'); ?>
<?php $__env->startSection('page_title', 'Presensi Siswa'); ?>

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

<style>
    .card-custom { background: white; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); overflow: hidden; }

    .header-prestasi {
        background-color: #123B6B; color: white; display: flex;
        justify-content: space-between; align-items: center;
        padding: 20px 25px; flex-wrap: wrap; gap: 12px;
    }
    .header-prestasi h4 { margin: 0; font-weight: 600; font-size: 1.2rem; }

    .presensi-toolbar {
        background: #f8f9fa; padding: 18px 25px; border-bottom: 1px solid #eee;
        display: flex; justify-content: space-between; align-items: center;
        flex-wrap: wrap; gap: 15px;
    }
    .toolbar-links { display: flex; gap: 10px; flex-wrap: wrap; }
    .btn-tambah {
        border: 2px solid #123B6B; color: #123B6B; background-color: transparent;
        padding: 9px 18px; border-radius: 8px; text-decoration: none;
        font-weight: 600; font-size: 13px; transition: 0.3s;
        display: inline-flex; align-items: center; gap: 6px;
    }
    .btn-tambah:hover { background-color: #123B6B; color: #fff; }
    .btn-tambah.solid { background-color: #123B6B; color: #fff; }
    .btn-tambah.solid:hover { background-color: #0f2e52; }

    .filter-select {
        padding: 10px 15px; border: 1px solid #ddd; border-radius: 8px;
        font-size: 14px; font-family: 'Poppins', sans-serif;
        color: #333; outline: none; transition: 0.2s;
    }
    .filter-select:focus { border-color: #123B6B; }

    .kelas-grid {
        display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
        gap: 18px; padding: 25px;
    }

    .kelas-card { border: 1px solid #eee; border-radius: 12px; padding: 18px; transition: 0.2s; background: #fff; }
    .kelas-card:hover { box-shadow: 0 4px 12px rgba(0,0,0,0.06); }
    .kelas-card.sudah { border-left: 4px solid #16a34a; background: #f0fdf4; }
    .kelas-card.belum { border-left: 4px solid #dc2626; background: #fef2f2; }

    .kelas-card-top { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 8px; gap: 8px; }
    .kelas-nama { font-weight: 700; font-size: 16px; color: #123B6B; margin: 0; }

    .status-pill { font-size: 11px; font-weight: 600; padding: 4px 10px; border-radius: 20px; white-space: nowrap; }
    .status-pill.sudah { background: #dcfce7; color: #166534; }
    .status-pill.belum { background: #fee2e2; color: #991b1b; }

    .kelas-meta { font-size: 13px; color: #555; margin: 4px 0; }
    .kelas-meta strong { color: #222; }
    .kelas-meta.kosong { color: #999; font-style: italic; }

    .kelas-link { display: inline-flex; align-items: center; gap: 6px; margin-top: 10px; font-size: 13px; font-weight: 600; color: #123B6B; text-decoration: none; }
    .kelas-link:hover { text-decoration: underline; }

    .empty-state { text-align: center; padding: 40px; color: #777; }
    .empty-state i { font-size: 30px; margin-bottom: 10px; color: #ccc; }

    @media (max-width: 768px) {
        .header-prestasi { flex-direction: column; text-align: center; }
        .presensi-toolbar { flex-direction: column; align-items: stretch; }
        .toolbar-links { justify-content: center; }
        .presensi-toolbar form { display: flex; justify-content: center; }
        .kelas-grid { grid-template-columns: 1fr; padding: 16px; }
    }
</style>

<div class="card-custom">

    <div class="header-prestasi">
        <h4><i class="fas fa-clipboard-check"></i> Presensi Siswa</h4>
        <div class="tanggal-jam" id="tanggal-jam"></div>
    </div>

    <div class="presensi-toolbar">
        <div class="toolbar-links">
            <a href="<?php echo e(route('admin.presensi.rekapBulanan')); ?>" class="btn-tambah solid">
                <i class="fas fa-calendar-alt"></i> Rekap Bulanan
            </a>
            <a href="<?php echo e(route('admin.presensi.rekapTotal')); ?>" class="btn-tambah">
                <i class="fas fa-chart-bar"></i> Rekap Total
            </a>
        </div>

        <form method="GET">
            <input type="date" name="tanggal" value="<?php echo e($tanggal); ?>" onchange="this.form.submit()" class="filter-select">
        </form>
    </div>

    <div class="kelas-grid">
        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="kelas-card <?php echo e($kelas['sudah_diinput'] ? 'sudah' : 'belum'); ?>">
                <div class="kelas-card-top">
                    <p class="kelas-nama"><?php echo e($kelas['rombel']); ?></p>
                    <span class="status-pill <?php echo e($kelas['sudah_diinput'] ? 'sudah' : 'belum'); ?>">
                        <?php echo e($kelas['sudah_diinput'] ? 'Sudah diinput' : 'Belum diinput'); ?>

                    </span>
                </div>

                <p class="kelas-meta">Koor Kelas: <strong><?php echo e($kelas['koor_nama'] ?? 'Belum ditentukan'); ?></strong></p>

                <?php if($kelas['sudah_diinput']): ?>
                    <p class="kelas-meta">Diinput oleh: <?php echo e($kelas['diinput_oleh'] ?? $kelas['diedit_oleh'] ?? '-'); ?></p>
                <?php else: ?>
                    <p class="kelas-meta kosong">Belum ada data untuk tanggal ini.</p>
                <?php endif; ?>

                <a href="<?php echo e(route('admin.presensi.kelas', ['rombel' => $kelas['rombel'], 'tanggal' => $tanggal])); ?>" class="kelas-link">
                    <?php echo e($kelas['sudah_diinput'] ? 'Lihat / Edit' : 'Input Sekarang'); ?> <i class="fas fa-arrow-right"></i>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="empty-state" style="grid-column: 1/-1;">
                <i class="far fa-folder-open"></i><br>
                Belum ada data kelas (rombel).
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
function updateClock() {
    const now = new Date();
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    const tanggal = now.toLocaleDateString('id-ID', options);
    const jam = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }).replace('.', ':');
    document.getElementById('tanggal-jam').innerHTML = `${tanggal}<br>${jam} WIB`;
}
setInterval(updateClock, 1000);
updateClock();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\Downloads\sintesa-skaduta\sintesa-skaduta\resources\views/admin/presensi/dashboard.blade.php ENDPATH**/ ?>