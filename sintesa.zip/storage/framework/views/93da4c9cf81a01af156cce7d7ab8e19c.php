<?php $__env->startSection('title', 'Presensi Kelas ' . $rombel); ?>
<?php $__env->startSection('page_title', 'Presensi Kelas ' . $rombel); ?>

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

<style>
    .card-custom { background: white; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); overflow: hidden; }

    .header-prestasi {
        background-color: #123B6B; color: white; display: flex;
        justify-content: space-between; align-items: flex-start;
        padding: 20px 25px; flex-wrap: wrap; gap: 15px;
    }
    .header-prestasi h4 { margin: 0 0 4px; font-weight: 600; font-size: 1.2rem; }
    .header-sub { font-size: 12.5px; opacity: 0.9; line-height: 1.6; }
    .header-prestasi .filter-select { min-width: 160px; }

    .alert-box { margin: 20px 25px 0; padding: 12px 16px; border-radius: 8px; font-size: 14px; }
    .alert-success { background: #dcfce7; color: #166534; border: 1px solid #bbf7d0; }
    .alert-error { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }

    .table-responsive { width: 100%; overflow-x: auto; -webkit-overflow-scrolling: touch; padding: 25px; }
    table { width: 100%; border-collapse: collapse; min-width: 700px; }
    thead { background-color: #2c3e50; color: white; }
    th, td { padding: 12px 14px; border-bottom: 1px solid #eee; text-align: left; font-size: 14px; vertical-align: middle; }
    th.status-col, td.status-col { text-align: center; width: 60px; }
    tbody tr:hover { background-color: #f9f9f9; }

    .radio-hadir { accent-color: #16a34a; }
    .radio-sakit { accent-color: #d97706; }
    .radio-izin { accent-color: #2563eb; }
    .radio-alpa { accent-color: #dc2626; }

    .link-file { color: #1e3a8a; text-decoration: none; font-weight: 500; font-size: 13px; }
    .link-file:hover { text-decoration: underline; }

    .btn-simpan {
        background-color: #123B6B; color: white; border: none;
        padding: 12px 20px; border-radius: 8px; cursor: pointer;
        font-weight: 600; font-size: 14px; width: 100%; margin-top: 5px;
        transition: 0.2s;
    }
    .btn-simpan:hover { background-color: #0f2e52; }

    .back-link { display: block; text-align: center; padding: 15px 0 20px; color: #123B6B; font-size: 13px; text-decoration: none; font-weight: 600; }
    .back-link:hover { text-decoration: underline; }

    @media (max-width: 768px) {
        .header-prestasi { flex-direction: column; text-align: center; }
        .table-responsive { padding: 15px; }
    }
</style>

<div class="card-custom">

    <div class="header-prestasi">
        <div>
            <h4>Kelas <?php echo e($rombel); ?></h4>
            <div class="header-sub">
                <?php if($sesi): ?>
                    Diinput oleh koor: <strong><?php echo e($sesi->koor->nama_lengkap ?? 'Admin/Kesiswaan langsung'); ?></strong>
                    <?php if($sesi->diedit_oleh): ?>
                        <br>Terakhir diedit: <?php echo e($sesi->diedit_oleh); ?> <?php if($sesi->diedit_at): ?> (<?php echo e($sesi->diedit_at->translatedFormat('d M Y H:i')); ?>) <?php endif; ?>
                    <?php endif; ?>
                <?php else: ?>
                    Belum ada data presensi untuk tanggal ini — kamu bisa input dari sini.
                <?php endif; ?>
            </div>
        </div>
        <form method="GET">
            <input type="date" name="tanggal" value="<?php echo e($tanggal); ?>" onchange="this.form.submit()" class="filter-select">
        </form>
    </div>

    <?php if(session('success')): ?>
        <div class="alert-box alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert-box alert-error"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.presensi.simpan', $rombel)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="tanggal" value="<?php echo e($tanggal); ?>">

        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>NIS</th>
                        <th>Nama</th>
                        <th class="status-col">Hadir</th>
                        <th class="status-col">Sakit</th>
                        <th class="status-col">Izin</th>
                        <th class="status-col">Alpa</th>
                        <th>Bukti</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $siswaSekelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $rec = $existing[$s->nis] ?? null; ?>
                        <tr>
                            <td><?php echo e($s->nis); ?></td>
                            <td><?php echo e($s->nama_lengkap); ?></td>
                            <?php $__currentLoopData = ['hadir', 'sakit', 'izin', 'alpa']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td class="status-col">
                                    <input type="radio" class="radio-<?php echo e($opt); ?>" name="status[<?php echo e($s->nis); ?>]" value="<?php echo e($opt); ?>"
                                           <?php echo e(($rec->status ?? 'hadir') === $opt ? 'checked' : ''); ?> required>
                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td>
                                <?php if($rec && $rec->bukti_path): ?>
                                    <a href="<?php echo e(asset('storage/' . $rec->bukti_path)); ?>" target="_blank" class="link-file"><i class="fa-solid fa-paperclip"></i> Lihat</a>
                                <?php else: ?>
                                    <span style="color:#aaa; font-size:12px;">-</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div style="padding: 0 25px 25px;">
            <button type="submit" class="btn-simpan">Simpan Presensi</button>
        </div>
    </form>

    <a href="<?php echo e(route('admin.presensi.dashboard')); ?>" class="back-link"><i class="fas fa-arrow-left"></i> Kembali ke Dashboard Presensi</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\Downloads\sintesa-skaduta\sintesa-skaduta\resources\views/admin/presensi/kelas.blade.php ENDPATH**/ ?>