<?php $__env->startSection('title', 'Rekap Bulanan Presensi'); ?>
<?php $__env->startSection('page_title', 'Rekap Bulanan Presensi'); ?>

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

<style>
    .card-custom { background: white; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); overflow: hidden; }

    .header-prestasi {
        background-color: #123B6B; color: white; display: flex;
        justify-content: space-between; align-items: center;
        padding: 20px 25px; flex-wrap: wrap; gap: 12px;
    }
    .header-prestasi h4 { margin: 0; font-weight: 600; font-size: 1.2rem; }

    .rekap-filter-wrapper {
        background: #f8f9fa; padding: 18px 25px; border-bottom: 1px solid #eee;
        display: flex; justify-content: space-between; align-items: center;
        flex-wrap: wrap; gap: 15px;
    }
    .filter-form { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
    .filter-select { padding: 10px 15px; border: 1px solid #ddd; border-radius: 8px; font-size: 14px; font-family: 'Poppins', sans-serif; color: #333; outline: none; }
    .filter-select:focus { border-color: #123B6B; }
    .back-link { color: #123B6B; font-size: 13px; text-decoration: none; font-weight: 600; }
    .back-link:hover { text-decoration: underline; }

    .table-responsive { width: 100%; overflow-x: auto; -webkit-overflow-scrolling: touch; padding: 20px 25px; }
    table { width: 100%; border-collapse: collapse; font-size: 12.5px; }
    thead { background-color: #2c3e50; color: white; }
    th, td { padding: 8px 6px; border-bottom: 1px solid #eee; text-align: center; }
    th:first-child, td:first-child { text-align: left; position: sticky; left: 0; background: #2c3e50; z-index: 2; padding-left: 12px; }
    td:first-child { background: #fff; color: #222; font-weight: 500; white-space: nowrap; }
    tbody tr:hover td:not(:first-child) { background-color: #f9f9f9; }
    tbody tr:hover td:first-child { background-color: #f4f7f6; }

    .badge-h { background: #16a34a; }
    .badge-s { background: #d97706; }
    .badge-i { background: #2563eb; }
    .badge-a { background: #dc2626; }
    .badge-day { display: inline-block; width: 18px; height: 18px; line-height: 18px; border-radius: 4px; color: #fff; font-size: 10px; font-weight: 700; }
    .dash { color: #ccc; }

    .col-total-h { background: #f0fdf4; font-weight: 700; color: #166534; }
    .col-total-s { background: #fffbeb; font-weight: 700; color: #92400e; }
    .col-total-i { background: #eff6ff; font-weight: 700; color: #1e40af; }
    .col-total-a { background: #fef2f2; font-weight: 700; color: #991b1b; }

    .legend { padding: 0 25px 20px; font-size: 12px; color: #888; }

    .empty-state { text-align: center; padding: 40px; color: #777; }

    @media (max-width: 768px) {
        .header-prestasi { flex-direction: column; text-align: center; }
        .rekap-filter-wrapper { flex-direction: column; align-items: stretch; }
        .filter-form { flex-direction: column; width: 100%; }
        .filter-select { width: 100%; }
    }
</style>

<div class="card-custom">
    <div class="header-prestasi">
        <h4><i class="fas fa-calendar-alt"></i> Rekap Bulanan Presensi</h4>
    </div>

    <div class="rekap-filter-wrapper">
        <form method="GET" class="filter-form">
            <select name="rombel" onchange="this.form.submit()" class="filter-select">
                <?php $__currentLoopData = $rombelList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($r); ?>" <?php echo e($r == $rombel ? 'selected' : ''); ?>><?php echo e($r); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <select name="bulan" onchange="this.form.submit()" class="filter-select">
                <?php $__currentLoopData = range(1,12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($m); ?>" <?php echo e($m == $bulan ? 'selected' : ''); ?>><?php echo e(\Carbon\Carbon::create()->month($m)->translatedFormat('F')); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <select name="tahun" onchange="this.form.submit()" class="filter-select">
                <?php $__currentLoopData = range(now()->year, now()->year - 2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($y); ?>" <?php echo e($y == $tahun ? 'selected' : ''); ?>><?php echo e($y); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </form>
        <a href="<?php echo e(route('admin.presensi.dashboard')); ?>" class="back-link"><i class="fas fa-arrow-left"></i> Kembali ke Dashboard</a>
    </div>

    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Nama</th>
                    <?php $__currentLoopData = $tanggalList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><th><?php echo e($t); ?></th><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <th class="col-total-h">H</th>
                    <th class="col-total-s">S</th>
                    <th class="col-total-i">I</th>
                    <th class="col-total-a">A</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $siswaSekelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($s->nama_lengkap); ?></td>
                        <?php $__currentLoopData = $tanggalList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $st = $grid[$s->nis][$t] ?? null; ?>
                            <td>
                                <?php if($st === 'hadir'): ?> <span class="badge-day badge-h">H</span>
                                <?php elseif($st === 'sakit'): ?> <span class="badge-day badge-s">S</span>
                                <?php elseif($st === 'izin'): ?> <span class="badge-day badge-i">I</span>
                                <?php elseif($st === 'alpa'): ?> <span class="badge-day badge-a">A</span>
                                <?php else: ?> <span class="dash">·</span>
                                <?php endif; ?>
                            </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td class="col-total-h"><?php echo e($totalPerSiswa[$s->nis]['hadir']); ?></td>
                        <td class="col-total-s"><?php echo e($totalPerSiswa[$s->nis]['sakit']); ?></td>
                        <td class="col-total-i"><?php echo e($totalPerSiswa[$s->nis]['izin']); ?></td>
                        <td class="col-total-a"><?php echo e($totalPerSiswa[$s->nis]['alpa']); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="100" class="empty-state">Tidak ada siswa di kelas ini.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <p class="legend">H = Hadir, S = Sakit, I = Izin, A = Alpa. Tanda (·) artinya tidak ada data presensi tanggal itu.</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\Downloads\sintesa-skaduta\sintesa-skaduta\resources\views/admin/presensi/rekap-bulanan.blade.php ENDPATH**/ ?>