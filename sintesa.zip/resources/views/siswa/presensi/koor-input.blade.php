@extends('layouts.siswa')

@section('title', 'Input Presensi Kelas')
@section('page_title', 'Input Presensi Kelas')

@section('content')

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

<style>
    :root {
        --primary: #1e3a8a; --primary-hover: #172554; --secondary: #64748b;
        --bg-light: #f1f5f9; --white: #ffffff;
        --shadow: 0 4px 6px -1px rgba(0,0,0,0.1), 0 2px 4px -1px rgba(0,0,0,0.06);
        --radius: 16px;
    }
    body { font-family: 'Poppins', sans-serif; background-color: var(--bg-light); }
    .dashboard-container { max-width: 1000px; margin: 0 auto; padding-bottom: 50px; }

    .header-card {
        background: linear-gradient(135deg, #17375d 0%, #102a48 100%);
        color: #fff; border-radius: 12px; padding: 25px 30px; margin-bottom: 25px;
        box-shadow: 0 4px 15px rgba(23, 55, 93, 0.2); position: relative; overflow: hidden;
    }
    .header-card::before { content: ''; position: absolute; top: -50px; right: -50px; width: 150px; height: 150px; background: rgba(255,255,255,0.1); border-radius: 50%; }
    .user-info h2 { font-size: 22px; font-weight: 700; margin: 0; }
    .user-info p { font-size: 14px; opacity: 0.9; margin-top: 5px; }
    .header-card input[type=date] {
        padding: 9px 14px; border-radius: 10px; border: none; font-size: 13px;
        font-family: 'Poppins', sans-serif; background: rgba(255,255,255,0.15); color: #fff;
    }
    .header-card input[type=date]::-webkit-calendar-picker-indicator { filter: invert(1); }

    .alert-flash { padding: 14px 18px; border-radius: 12px; font-size: 14px; margin-bottom: 20px; }
    .alert-success { background: #dcfce7; color: #166534; }
    .alert-error { background: #fee2e2; color: #991b1b; }
    .alert-warning { background: #fef3c7; color: #92400e; }

    .content-card { background: var(--white); border-radius: var(--radius); padding: 25px; box-shadow: var(--shadow); margin-bottom: 20px; }
    .content-title { font-size: 16px; font-weight: 700; color: var(--primary); margin: 0 0 6px; display: flex; align-items: center; gap: 8px; }
    .content-desc { font-size: 13px; color: var(--secondary); margin-bottom: 20px; }

    .table-responsive { width: 100%; overflow-x: auto; }
    .custom-table { width: 100%; border-collapse: collapse; min-width: 560px; }
    .custom-table thead { background-color: #f8fafc; border-bottom: 2px solid #e2e8f0; }
    .custom-table th { text-align: left; padding: 12px 14px; font-size: 12px; font-weight: 600; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; }
    .custom-table th.center { text-align: center; }
    .custom-table td { padding: 12px 14px; vertical-align: middle; font-size: 14px; color: #334155; border-bottom: 1px solid #f1f5f9; }
    .custom-table td.center { text-align: center; }
    .custom-table tr:hover { background-color: #f8fafc; }

    input[type=radio].r-hadir { accent-color: #16a34a; }
    input[type=radio].r-sakit { accent-color: #d97706; }
    input[type=radio].r-izin { accent-color: #2563eb; }
    input[type=radio].r-alpa { accent-color: #dc2626; }
    input[type=radio] { width: 17px; height: 17px; cursor: pointer; }

    .badge { padding: 5px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; display: inline-block; }
    .badge-hadir { background: #dcfce7; color: #166534; }
    .badge-sakit { background: #fef3c7; color: #92400e; }
    .badge-izin { background: #dbeafe; color: #1e40af; }
    .badge-alpa { background: #fee2e2; color: #991b1b; }

    .btn-submit { width: 100%; background: var(--primary); color: white; padding: 13px; border: none; border-radius: 12px; font-size: 15px; font-weight: 600; cursor: pointer; margin-top: 18px; }
    .btn-submit:hover { background: var(--primary-hover); }

    .link-riwayat { display: block; text-align: center; margin-top: 5px; color: var(--primary); font-size: 13px; font-weight: 600; text-decoration: none; }
    .link-riwayat:hover { text-decoration: underline; }

    @media (max-width: 768px) {
        .header-card { flex-direction: column; text-align: center; padding: 20px; }
        .custom-table th, .custom-table td { padding: 10px 8px; font-size: 13px; }
    }
</style>

<div class="dashboard-container">

    <div class="header-card">
        <div class="user-info">
            <h2><i class="bi bi-clipboard-check"></i> Presensi Kelas {{ $rombel }}</h2>
            <p>Koor: {{ $koor->nama_lengkap }} (NIS {{ $koor->nis }})</p>
        </div>
        <form method="GET">
            <input type="date" name="tanggal" value="{{ $tanggal }}" max="{{ now()->toDateString() }}" onchange="this.form.submit()">
        </form>
    </div>

    @if (session('success'))
        <div class="alert-flash alert-success">{{ session('success') }}</div>
    @endif
    @if (session('error'))
        <div class="alert-flash alert-error">{{ session('error') }}</div>
    @endif

    <div class="content-card">
        @if ($sudahDiinput)
            <div class="alert-flash alert-warning" style="margin-bottom:20px;">
                Presensi tanggal <strong>{{ \Carbon\Carbon::parse($tanggal)->translatedFormat('d F Y') }}</strong>
                sudah diinput dan <strong>tidak bisa diubah</strong> dari sini. Kalau ada kesalahan, hubungi Admin/Kesiswaan.
            </div>

            <div class="table-responsive">
                <table class="custom-table">
                    <thead><tr><th>NIS</th><th>Nama</th><th>Status</th></tr></thead>
                    <tbody>
                        @foreach ($siswaSekelas as $s)
                            @php $st = $existingStatus[$s->nis] ?? null; @endphp
                            <tr>
                                <td>{{ $s->nis }}</td>
                                <td>{{ $s->nama_lengkap }}</td>
                                <td>@if($st)<span class="badge badge-{{ $st }}">{{ ucfirst($st) }}</span>@else - @endif</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @else
            <p class="content-title"><i class="bi bi-check2-square"></i> Isi Presensi Hari Ini</p>
            <p class="content-desc">Pilih status setiap siswa. Default: <strong>Hadir</strong>. Presensi ini hanya bisa disimpan <strong>sekali</strong> untuk tanggal ini.</p>

            <form action="{{ route('siswa.presensi.koor.store') }}" method="POST"
                  onsubmit="return confirm('Yakin? Presensi hari ini hanya bisa disimpan sekali dan tidak bisa diubah lagi olehmu.')">
                @csrf
                <input type="hidden" name="tanggal" value="{{ $tanggal }}">

                <div class="table-responsive">
                    <table class="custom-table">
                        <thead>
                            <tr>
                                <th>NIS</th><th>Nama</th>
                                <th class="center">Hadir</th><th class="center">Sakit</th>
                                <th class="center">Izin</th><th class="center">Alpa</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($siswaSekelas as $s)
                                <tr>
                                    <td>{{ $s->nis }}</td>
                                    <td>{{ $s->nama_lengkap }}</td>
                                    @foreach (['hadir', 'sakit', 'izin', 'alpa'] as $opt)
                                        <td class="center">
                                            <input type="radio" class="r-{{ $opt }}" name="status[{{ $s->nis }}]" value="{{ $opt }}" {{ $opt === 'hadir' ? 'checked' : '' }} required>
                                        </td>
                                    @endforeach
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>

                <button type="submit" class="btn-submit">Simpan Presensi</button>
            </form>
        @endif

        <a href="{{ route('siswa.presensi.koor.riwayat') }}" class="link-riwayat">Lihat riwayat presensi yang pernah diinput</a>
    </div>
</div>
@endsection
